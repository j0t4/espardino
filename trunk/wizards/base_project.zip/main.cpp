//
// Copyright (c) 2009  http://www.espardino.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#include <micro214x.h>
#include <vcom.h>



int main(void)
{
	int data;

	LEDS_init();	/* init the LEDs for this board  */
	VCOM_init();	/* init the USB Virtual COM port */
	delay_init();	/* init the delay subroutines*/


	xprintf_output(&VCOM_putchar);	/* define the output for the printf/puts */


	DigitalIO my_output(P0_0);
	DigitalIO my_input(P0_1);

	DigitalBus my_bus(P1_24,P1_25,P1_26,P1_27,P1_28,P1_29,P1_30,P1_31);

	while(1)
	{

		data = my_bus.read();
		delay_ms(500);
		my_output.on();
		LEDS_on(LED1);
		delay_ms(500);
		my_output.off();
		LEDS_off(LED1);

		 xprintf("my_input=%d, my_bus=%04x\r\n",my_input.read(),my_bus.read());

   }
}




